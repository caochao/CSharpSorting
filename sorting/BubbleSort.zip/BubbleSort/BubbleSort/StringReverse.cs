﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace BubbleSort
{
    public class StringReverse
    {
        /// <summary>
        /// 字符串逆转并去除空格
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ReverseAndDeleteWhiteSpace(string str)
        {
            if (string.IsNullOrEmpty(str))
            {
                throw new ArgumentException();
            }

            int length = str.Length;
            StringBuilder sb = new StringBuilder(length);

            for (int i = length - 1; i >= 0; i--)
            {
                char c = str[i];
                if (char.IsWhiteSpace(c))
                {
                    continue;
                }
                sb.Append(c);
            }
            return sb.ToString();
        }

        public delegate string funcDelegate(string s);

        /// <summary>
        /// 测试方法
        /// </summary>
        /// <param name="description">方法描述</param>
        /// <param name="func">测试方法</param>
        /// <param name="times">执行次数</param>
        /// <param name="str">测试字符串</param>
        public static void Benchmark(string description, funcDelegate func, int times, string str)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            for (int j = 0; j < times; j++)
            {
                func(str);
            }
            sw.Stop();
            Console.WriteLine("方法{0}：调用{1}次,用时{2} Ticks，{3}毫秒.", description, times, sw.ElapsedTicks, sw.ElapsedMilliseconds);
        }

        /// <summary>
        /// 生成指定长度随机字符串
        /// </summary>
        /// <param name="length">字条串长度</param>
        /// <returns></returns>
        public static string RandomString(int length)
        {
            Random random = new Random();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < length; i++)
            {
                sb.Append(Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65))));
            }
            return sb.ToString();
        }

        /// <summary>
        /// 字符串逆转-StringBuilder实现
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ReverseUsingStringBuilder(string str)
        {
            int length = str.Length;
            StringBuilder sb = new StringBuilder(length);

            for (int i = length - 1; i >= 0; i--)
            {
                sb.Append(str[i]);
            }
            return sb.ToString();
        }

        /// <summary>
        /// 字符串逆转-CharArray实现
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ReverseUsingCharArray(string str)
        {
            char[] arr = str.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }

        /// <summary>
        /// 字符串逆转-异或实现
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ReverseUsingXor(string str)
        {
            char[] arr = str.ToCharArray();
            int l = str.Length - 1;

            //交换值
            for (int i = 0; i < l; i++, l--)
            {
                arr[i] ^= arr[l];
                arr[l] ^= arr[i];
                arr[i] ^= arr[l];
            }
            return new string(arr);
        }
    }
}