﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BubbleSort
{
    class Program
    {
        static void Main(string[] args)
        {
            int size = 50;
            int[] orgArr = new int[size];

            Random r = new Random();
            for (int i = 0; i < size; i++)
            {
                orgArr[i] = r.Next(0, 101); //0到100的随机数
            }


            //冒泡排序
            //int[] sortedArray = Sort.BubbleSort(orgArr);

            //插入排序
            //int[] sortedArray = Sort.InsertionSort(orgArr);

            //选择排序
            //int[] sortedArray = Sort.SelectionSort(orgArr);

            //希尔排序
            //int[] sortedArray = Sort.ShellSort(orgArr);

            //归并排序
            int[] sortedArray = Sort.MergeSort(orgArr);

            for (int i = 0, l = sortedArray.Length; i < l; i++)
            {
                Console.WriteLine(sortedArray[i]);
            }

        }


        //static void Main(string[] args)
        //{
        //    string str = "welcome to caochao's blog  !";
        //    Console.WriteLine(StringReverse.ReverseUsingXor(str));
        //}

        //static void Main(string[] args)
        //{
        //    int[] lengths = new int[] { 1, 10, 15, 25, 50, 75, 100, 1000, 100000 };

        //    foreach (int len in lengths)
        //    {
        //        //每个方法都执行10000次，力求精确
        //        int iterations = 10000;

        //        //生成随机测试字符串
        //        string testString = StringReverse.RandomString(len);

        //        //打印测试信息
        //        StringReverse.Benchmark(String.Format("String Builder (测试字符串长度为{0})", len), StringReverse.ReverseUsingStringBuilder, iterations, testString);
        //        StringReverse.Benchmark(String.Format("Array.Reverse (测试字符串长度为{0})", len), StringReverse.ReverseUsingCharArray, iterations, testString);
        //        StringReverse.Benchmark(String.Format("Xor (测试字符串长度为{0})", len), StringReverse.ReverseUsingXor, iterations, testString);

        //        Console.WriteLine();
        //    }
        //    Console.Read();
        //}

        //static void Main(string[] args)
        //{
        //    Console.WriteLine(GenericTest.Select<string, int>("test"));
        //}
    }
}
