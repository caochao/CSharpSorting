﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BubbleSort
{
    public static class GenericTest
    {
        /// <summary>
        /// 泛型方法，方法名后需用符号"<>"，符号中加上类型参数
        /// </summary>
        /// <typeparam name="Tsource"></typeparam>
        /// <typeparam name="Tresult"></typeparam>
        /// <param name="tsource"></param>
        /// <returns></returns>
        public static Tresult Select<Tsource, Tresult>(Tsource tsource)
        {
            Tresult t = default(Tresult);
            return t;
        }
    }
}
