﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BubbleSort
{
    public class Sort
    {
        /// <summary>
        /// 对一个int数组进行冒泡排序
        /// </summary>
        /// <param name="array">要排序的数组</param>
        /// <returns>排序后的数组</returns>
        public static int[] BubbleSort(int[] array)
        {
            //if (array.GetType() != typeof(int[]))
            //{
            //    throw new ArgumentException("this method needs a int array");
            //}

            for (int i = 0, l = array.Length; i < l - 1; i++)
            {
                for (int j = i + 1; j < l; j++)
                {
                    if (array[i] >= array[j])
                    {
                        //int t = array[j];
                        //array[j] = array[i];
                        //array[i] = t;

                        //或者用异或运算
                        array[i] = array[i] ^ array[j];
                        array[j] = array[i] ^ array[j];
                        array[i] = array[i] ^ array[j];
                    }
                }
            }
            return array;
        }

        /// <summary>
        /// 插入排序
        /// </summary>
        /// <param name="array">要排序的数组</param>
        /// <returns>排序后的数组</returns>
        public static int[] InsertionSort(int[] array)
        {
            for (int i = 1, len = array.Length; i < len; i++)
            {
                for (int j = i; j > 0 && array[j] < array[j - 1]; j--)
                {
                    array[j] ^= array[j - 1];
                    array[j - 1] ^= array[j];
                    array[j] ^= array[j - 1];
                }
            }
            return array;
        }

        public static int[] SelectionSort(int[] array)
        {
            for (int i = 0, len = array.Length; i < len; i++)
            {
                int k = i;
                for (int j = i + 1; j < len; j++)
                {
                    if (array[k] > array[j])
                    {
                        k = j;  //一趟中最小值的数组下标
                    }
                    //如果恰巧第i趟第i个数为最小值时，则可省略一步交换
                    if (k != i)
                    {
                        array[i] ^= array[k];
                        array[k] ^= array[i];
                        array[i] ^= array[k];
                    }
                }
            }
            return array;
        }

        public static int[] ShellSort(int[] array)
        {
            int h = 0, len = array.Length;
            while (h < len)
            {
                h = h * 3 + 1;  //能提升效率的增量序列,1,4,7,13...
            }
            while (h > 0)
            {
                //以增量h的插入排序
                for (int i = h; i < len; i++)
                {
                    for (int j = i; j - h >= 0 && array[j] < array[j - h]; j -= h)
                    {
                        array[j] ^= array[j - h];
                        array[j - h] ^= array[j];
                        array[j] ^= array[j - h];
                    }
                }
                h = (h - 1) / 3;    //增量递减。最后h一定会为1，即直接插入排序，保证数据一定有序
            }
            return array;
        }

        //#region 归并排序

        //private static int[] merge(int[] left, int[] right)
        //{
        //    int i = 0, lp = 0, rp = 0, llen = left.Length, rlen = right.Length;
        //    int[] result = new int[llen + rlen];

        //    //逐一比较left和right子数组元素，将两者较小值放入结果数组
        //    while (lp < llen && rp < rlen)
        //    {
        //        if (left[lp] <= right[rp])
        //        {
        //            result[i++] = left[lp++];
        //        }
        //        else
        //        {
        //            result[i++] = right[rp++];
        //        }
        //    }
        //    //right子数组为空
        //    while (lp < llen)
        //    {
        //        result[i++] = left[lp++];
        //    }
        //    //left子数组为空
        //    while (rp < rlen)
        //    {
        //        result[i++] = right[rp++];
        //    }
        //    return result;
        //}

        //public static int[] MergeSort(int[] array)
        //{
        //    int len = array.Length, mid = len / 2;
        //    if (len < 2)
        //        return array;
        //    int[] _left = new int[mid];
        //    int[] _right = new int[len - mid];
        //    Array.Copy(array, 0, _left, 0, mid);
        //    Array.Copy(array, mid, _right, 0, len - mid);
        //    return merge(MergeSort(_left), MergeSort(_right));
        //}

        //#endregion

        #region 归并排序

        private static void merge(int[] array, int low, int m, int high)
        {
            int i = low, j = m + 1, p = 0;
            int[] result = new int[high - low + 1];

            while (i <= m && j <= high)
            {
                result[p++] = array[i] <= array[j] ? array[i++] : array[j++];
            }
            while (i <= m)
            {
                result[p++] = array[i++];
            }
            while (j <= high)
            {
                result[p++] = array[j++];
            }
            //一趟归并完成后将结果复制回原数组
            for (p = 0, i = low; i <= high; p++, i++)
            {
                array[i] = result[p];
            }
        }

        private static int[] recMerge(int[] array, int low, int high)
        {
            int mid;
            if (low < high) //区间长度大于1
            {
                mid = (low + high) / 2;
                recMerge(array, low, mid);
                recMerge(array, mid + 1, high);
                merge(array, low, mid, high);
            }
            return array;
        }

        public static int[] MergeSort(int[] array)
        {
            return recMerge(array, 0, array.Length - 1);
        }

        #endregion
    }
}
